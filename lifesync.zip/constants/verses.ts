
export interface Verse {
  sanskrit: string;
  transliteration: string;
  translation: string;
  source: string;
  meaning: string;
}

export const DHARMA_VERSES: Verse[] = [
  {
    sanskrit: "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन।",
    transliteration: "Karmanye vadhikaraste ma phaleshu kadachana",
    translation: "You have a right to perform your prescribed duties, but you are not entitled to the fruits of your actions.",
    source: "Bhagavad Gita 2.47",
    meaning: "Focus on the process and your effort rather than being paralyzed by the anxiety of the outcome."
  },
  {
    sanskrit: "योग: कर्मसु कौशलम्।",
    transliteration: "Yogah karmasu kaushalam",
    translation: "Yoga is excellence in action.",
    source: "Bhagavad Gita 2.50",
    meaning: "True spiritual connection is found through performing your daily tasks with total focus and skill."
  },
  {
    sanskrit: "उद्धरेदात्मनात्मानं नात्मानमवसादयेत्।",
    transliteration: "Uddhared atmanatmanam natmanam avasadayet",
    translation: "Elevate yourself through the power of your own mind, and do not let yourself degrade.",
    source: "Bhagavad Gita 6.5",
    meaning: "You are your own best friend and your own worst enemy. Self-discipline is the key to growth."
  },
  {
    sanskrit: "श्रद्धावान् लभते ज्ञानं।",
    transliteration: "Shraddhavan labhate jnanam",
    translation: "The man of faith, the devoted, the master of his senses, obtains knowledge.",
    source: "Bhagavad Gita 4.39",
    meaning: "Learning requires humility, focus, and a deep conviction in the path you are taking."
  },
  {
    sanskrit: "न हि कश्चित्क्षणमपि जातु तिष्ठत्यकर्मकृत्।",
    transliteration: "Na hi kashchit kshanam api jatu tishthaty akarmakrit",
    translation: "No one can remain even for a moment without performing some action.",
    source: "Bhagavad Gita 3.5",
    meaning: "Action is inevitable; the secret to a good life is choosing the right actions consciously."
  }
];
