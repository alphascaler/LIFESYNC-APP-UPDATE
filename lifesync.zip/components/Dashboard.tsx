
import React, { useState, useMemo, useEffect } from 'react';
import { 
  CheckCircle2, 
  BookMarked, 
  Info, 
  Crosshair, 
  Plus, 
  Flame, 
  BarChart3, 
  AlertCircle, 
  Activity, 
  Clock, 
  Share2,
  Copy,
  Check,
  Smartphone,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { Task, Habit, Tab, AppState } from '../types';
import { BarChart as ReBarChart, Bar, XAxis, ResponsiveContainer, Tooltip, LineChart, Line } from 'recharts';
import { DHARMA_VERSES } from '../constants/verses';

interface DashboardProps {
  tasks: Task[];
  habits: Habit[];
  history: Record<string, number>;
  dailyPriority?: AppState['dailyPriority'];
  setDailyPriority: (priority: AppState['dailyPriority']) => void;
  onNavigate: (tab: Tab) => void;
  canInstall?: boolean;
  onInstall?: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  tasks, 
  habits, 
  history, 
  dailyPriority, 
  setDailyPriority, 
  onNavigate, 
  canInstall, 
  onInstall 
}) => {
  const [showMeaning, setShowMeaning] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [showReports, setShowReports] = useState(false);
  const [goalInput, setGoalInput] = useState('');

  // Progress Calculation
  const pendingTasks = tasks.filter(t => !t.completed).length;
  const completedHabits = habits.filter(h => h.completed).length;
  const habitTotal = habits.length;
  const taskTotal = tasks.length;
  
  const dailyProgress = useMemo(() => {
    const totalItems = habitTotal + taskTotal;
    if (totalItems === 0) return 0;
    const completedItems = completedHabits + (taskTotal - pendingTasks);
    return Math.round((completedItems / totalItems) * 100);
  }, [habitTotal, taskTotal, completedHabits, pendingTasks]);

  const statusHeading = useMemo(() => {
    if (dailyProgress === 0) return "GETTING STARTED.";
    if (dailyProgress <= 40) return "INITIATED.";
    if (dailyProgress <= 80) return "IN MOTION.";
    if (dailyProgress < 100) return "DOMINATING.";
    return "IN CONTROL.";
  }, [dailyProgress]);

  const getMonthStats = (monthOffset: number) => {
    const targetDate = new Date();
    targetDate.setMonth(targetDate.getMonth() - monthOffset);
    const month = targetDate.getMonth();
    const year = targetDate.getFullYear();
    const monthName = targetDate.toLocaleString('default', { month: 'long' });

    const entries = (Object.entries(history) as [string, number][]).filter(([dateStr]) => {
      const d = new Date(dateStr);
      return d.getMonth() === month && d.getFullYear() === year;
    });

    const scores = entries.map(([_, s]) => s);
    const perfectDays = scores.filter(s => s === 100).length;
    const successDays = scores.filter(s => s > 0).length;
    const avgScore = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;

    let weeklyData: any[] = [];
    if (monthOffset === 0 && entries.length > 0) {
      const weeks: Record<number, number[]> = {};
      entries.forEach(([dateStr, score]) => {
        const d = new Date(dateStr);
        const weekNum = Math.ceil(d.getDate() / 7);
        if (!weeks[weekNum]) weeks[weekNum] = [];
        weeks[weekNum].push(score);
      });
      weeklyData = (Object.entries(weeks) as [string, number[]][]).map(([w, s]) => ({
        week: `Week ${w}`,
        avg: Math.round(s.reduce((a, b) => a + b, 0) / s.length)
      }));
    }

    return { monthName, perfectDays, successDays, avgScore, count: scores.length, weeklyData };
  };

  const monthlyReports = useMemo(() => [
    getMonthStats(0),
    getMonthStats(1),
    getMonthStats(2)
  ], [history]);

  const stats = useMemo(() => {
    const historyEntries = (Object.entries(history) as [string, number][]).sort((a, b) => new Date(b[0]).getTime() - new Date(a[0]).getTime());
    const totalPerfect = historyEntries.filter(([_, score]) => score === 100).length;
    
    let activeStreak = 0;
    const today = new Date().toLocaleDateString('en-CA');
    let checkDate = new Date();
    while (true) {
      const dateStr = checkDate.toLocaleDateString('en-CA');
      if (history[dateStr] && history[dateStr] > 0) {
        activeStreak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        if (dateStr === today) {
          checkDate.setDate(checkDate.getDate() - 1);
          continue;
        }
        break;
      }
      if (activeStreak > 365) break;
    }

    return { totalPerfect, activeStreak };
  }, [history]);

  const weakestLink = useMemo(() => {
    if (habits.length === 0) return null;
    const sorted = [...habits].sort((a, b) => a.streak - b.streak);
    return sorted[0];
  }, [habits]);

  const chartData = (Object.entries(history) as [string, number][])
    .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
    .slice(-7)
    .map(([date, score]) => ({
      name: new Date(date).toLocaleDateString('en-US', { weekday: 'short' }),
      score: score
    }));

  const verse = useMemo(() => {
    const day = new Date().getDate();
    return DHARMA_VERSES[day % DHARMA_VERSES.length];
  }, []);

  const handleSetGoal = () => {
    if (!goalInput.trim()) return;
    setDailyPriority({ text: goalInput.trim(), completed: false });
    setShowGoalModal(false);
    setGoalInput('');
  };

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-40">
      
      {/* Dynamic Status Banner */}
      <div className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full -mr-16 -mt-16 group-hover:scale-110 transition-transform duration-700" />
        <div className="relative z-10">
          <div className="flex justify-between items-start">
            <h2 className="text-3xl font-extrabold tracking-tighter italic uppercase text-slate-900">
              {statusHeading}
            </h2>
            <div className="bg-orange-50 px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-orange-100">
              <Flame className="w-3.5 h-3.5 text-orange-500 fill-orange-500" />
              <span className="text-[10px] font-black text-orange-600 uppercase tracking-widest">{stats.activeStreak} DAY STREAK</span>
            </div>
          </div>
          <p className="text-slate-400 text-sm mt-2 font-medium">Daily completion: {dailyProgress}%</p>
          
          <div className="mt-8 grid grid-cols-2 gap-4">
            <div className="bg-slate-50 border border-slate-100 p-4 rounded-3xl">
              <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-1">Perfect Days</p>
              <span className="text-2xl font-black text-slate-800">{stats.totalPerfect}</span>
            </div>
            <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-3xl">
              <p className="text-[9px] font-black uppercase text-indigo-400 tracking-widest mb-1">Efficiency</p>
              <span className="text-2xl font-black text-indigo-600">{dailyProgress}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Selector */}
      <div className="bg-slate-100 p-1.5 rounded-3xl flex gap-1">
        <button 
          onClick={() => setShowReports(false)}
          className={`flex-1 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${!showReports ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400'}`}
        >
          Daily View
        </button>
        <button 
          onClick={() => setShowReports(true)}
          className={`flex-1 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${showReports ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400'}`}
        >
          Status Reports
        </button>
      </div>

      {!showReports ? (
        <div className="space-y-6 animate-in slide-in-from-left-4 duration-300">
          {/* Daily Goal */}
          {dailyPriority ? (
            <div 
              onClick={() => setDailyPriority({ ...dailyPriority, completed: !dailyPriority.completed })}
              className={`p-6 rounded-[2.5rem] border transition-all cursor-pointer ${dailyPriority.completed ? 'bg-emerald-50 border-emerald-100 opacity-70' : 'bg-white border-indigo-100 shadow-xl shadow-indigo-50'}`}
            >
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-500 ${dailyPriority.completed ? 'bg-emerald-500 text-white' : 'bg-indigo-600 text-white'}`}>
                  {dailyPriority.completed ? <CheckCircle2 className="w-6 h-6" /> : <Crosshair className="w-6 h-6" />}
                </div>
                <div className="flex-1">
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Today's Focus</p>
                  <h3 className={`text-base font-bold ${dailyPriority.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>{dailyPriority.text}</h3>
                </div>
              </div>
            </div>
          ) : (
            <button onClick={() => setShowGoalModal(true)} className="w-full bg-white border-2 border-dashed border-slate-200 p-8 rounded-[2.5rem] flex flex-col items-center justify-center text-slate-400 hover:border-indigo-300 transition-colors">
              <Plus className="w-6 h-6 mb-2" />
              <span className="text-[10px] font-black uppercase tracking-widest">Set Today's Main Objective</span>
            </button>
          )}

          {/* Mini Stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white p-6 rounded-[2rem] border border-slate-100 flex flex-col items-center text-center shadow-sm">
              <Activity className="w-6 h-6 text-indigo-500 mb-2" />
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Status</span>
              <span className="text-xl font-black text-slate-800 mt-1">{dailyProgress}%</span>
            </div>
            <div className="bg-white p-6 rounded-[2rem] border border-slate-100 flex flex-col items-center text-center shadow-sm">
              <Clock className="w-6 h-6 text-emerald-500 mb-2" />
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Pending</span>
              <span className="text-xl font-black text-slate-800 mt-1">{(taskTotal - (taskTotal - pendingTasks)) + (habitTotal - completedHabits)}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
          
          {/* Monthly Comparison Grid */}
          <div className="space-y-4">
             <h3 className="text-[10px] font-black uppercase text-slate-400 tracking-widest px-2">Quarterly Analysis</h3>
             <div className="flex gap-4 overflow-x-auto no-scrollbar -mx-6 px-6 pb-2">
                {monthlyReports.map((report, i) => (
                  <div key={i} className={`min-w-[240px] p-6 rounded-[2.5rem] border ${i === 0 ? 'bg-indigo-50 border-indigo-100' : 'bg-white border-slate-100'} space-y-4`}>
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-black uppercase text-slate-500">{report.monthName}</span>
                      <BarChart3 className={`w-4 h-4 ${i === 0 ? 'text-indigo-500' : 'text-slate-300'}`} />
                    </div>
                    <div>
                      <span className="text-3xl font-black text-slate-900">{report.avgScore}%</span>
                      <p className="text-[9px] font-bold text-slate-400 uppercase">Avg Completion</p>
                    </div>
                    <div className="grid grid-cols-2 gap-2 pt-4 border-t border-slate-200/50">
                      <div>
                        <p className="text-xs font-black text-slate-700">{report.perfectDays}</p>
                        <p className="text-[8px] font-bold text-slate-400 uppercase">Perfect</p>
                      </div>
                      <div>
                        <p className="text-xs font-black text-slate-700">{report.successDays}</p>
                        <p className="text-[8px] font-bold text-slate-400 uppercase">Success</p>
                      </div>
                    </div>
                  </div>
                ))}
             </div>
          </div>

          {/* Weekly Breakdown */}
          {monthlyReports[0].weeklyData.length > 0 && (
            <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
              <h3 className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-6">Weekly Performance</h3>
              <div className="h-40 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ReBarChart data={monthlyReports[0].weeklyData}>
                    <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{fontSize: 9, fontWeight: 800, fill: '#94a3b8'}} />
                    <Tooltip cursor={{fill: '#f1f5f9'}} contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                    <Bar dataKey="avg" fill="#4f46e5" radius={[6, 6, 6, 6]} barSize={24} />
                  </ReBarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Missing Activities / Weakest Link */}
          {weakestLink && (
            <div className="bg-orange-50 border border-orange-100 p-6 rounded-[2.5rem] flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-orange-500 text-white flex items-center justify-center shrink-0 shadow-lg shadow-orange-100">
                <AlertCircle className="w-7 h-7" />
              </div>
              <div className="flex-1">
                <p className="text-[9px] font-black uppercase tracking-widest text-orange-600 mb-1">Attention Required</p>
                <h4 className="text-base font-bold text-slate-900 truncate uppercase italic tracking-tight">"{weakestLink.text}"</h4>
                <p className="text-[10px] text-orange-700 font-medium mt-1">This is your most missed activity. Focus here tomorrow to rebuild your streak.</p>
              </div>
            </div>
          )}

          {/* Trend Line */}
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
            <h3 className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-6">Last 7 Days Trend</h3>
            <div className="h-40 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 9, fontWeight: 800, fill: '#94a3b8'}} />
                  <Tooltip contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                  <Line type="monotone" dataKey="score" stroke="#4f46e5" strokeWidth={4} dot={{ r: 4, fill: '#4f46e5', stroke: '#fff', strokeWidth: 2 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Mini Verse Footer */}
      <div 
        className="fixed bottom-24 left-6 right-6 bg-white/90 backdrop-blur-md border border-slate-100 p-4 rounded-3xl flex items-center justify-between gap-3 cursor-pointer shadow-lg z-40"
        onClick={() => setShowMeaning(!showMeaning)}
      >
        <div className="flex items-center gap-3 overflow-hidden">
          <BookMarked className="w-4 h-4 text-orange-500 shrink-0" />
          <p className="text-[11px] font-bold text-slate-600 truncate italic">"{verse.translation}"</p>
        </div>
        <Info className={`w-4 h-4 transition-colors ${showMeaning ? 'text-indigo-500' : 'text-slate-300'}`} />
      </div>

      {showMeaning && (
        <div className="fixed inset-x-6 bottom-40 p-6 bg-white border border-slate-100 rounded-[2rem] shadow-2xl z-50 animate-in zoom-in-95 max-w-sm mx-auto">
          <p className="text-[10px] font-black uppercase text-orange-500 mb-2">{verse.source}</p>
          <p className="text-sm font-bold text-slate-800 font-serif mb-2">{verse.sanskrit}</p>
          <p className="text-xs text-slate-500 leading-relaxed">{verse.meaning}</p>
          <button onClick={() => setShowMeaning(false)} className="w-full mt-4 py-3 bg-slate-900 text-white text-[10px] font-black uppercase rounded-xl">Close</button>
        </div>
      )}

      {/* Goal Modal */}
      {showGoalModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-sm rounded-[3rem] p-8 shadow-2xl relative animate-in zoom-in-95">
             <h3 className="text-xl font-black italic uppercase tracking-tighter mb-6">Today's Objective.</h3>
             <input 
              autoFocus
              type="text"
              value={goalInput}
              onChange={(e) => setGoalInput(e.target.value)}
              placeholder="What is the one thing?"
              className="w-full p-5 bg-slate-50 border-none rounded-2xl text-base font-bold text-slate-800 placeholder:text-slate-300 mb-4 focus:ring-4 focus:ring-indigo-50 transition-all"
             />
             <div className="flex gap-3">
               <button onClick={() => setShowGoalModal(false)} className="flex-1 py-4 bg-slate-100 text-slate-500 text-[10px] font-black uppercase rounded-2xl">Cancel</button>
               {/* Fixed missing onClick attribute and closing brace error causing JSX parser confusion */}
               <button onClick={handleSetGoal} className="flex-1 py-4 bg-indigo-600 text-white text-[10px] font-black uppercase rounded-2xl shadow-xl shadow-indigo-100">Commit</button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
