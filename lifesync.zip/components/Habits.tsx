
import React, { useState } from 'react';
import { Zap, Plus, CheckCircle2, Trash2, Flame, RotateCcw } from 'lucide-react';
import { Habit } from '../types';

interface HabitsProps {
  habits: Habit[];
  setHabits: React.Dispatch<React.SetStateAction<Habit[]>>;
  setHistory: React.Dispatch<React.SetStateAction<Record<string, number>>>;
}

const Habits: React.FC<HabitsProps> = ({ habits, setHabits, setHistory }) => {
  const [newHabit, setNewHabit] = useState('');
  const todayKey = new Date().toLocaleDateString('en-CA');

  const addHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabit.trim()) return;
    const habit: Habit = {
      id: Date.now().toString(),
      text: newHabit.trim(),
      completed: false,
      streak: 0
    };
    setHabits([...habits, habit]);
    setNewHabit('');
  };

  const toggleHabit = (id: string) => {
    const updated = habits.map(h => {
      if (h.id === id) {
        const completed = !h.completed;
        return { ...h, completed, streak: completed ? h.streak + 1 : Math.max(0, h.streak - 1) };
      }
      return h;
    });
    setHabits(updated);
    
    // Update history score
    const score = updated.length > 0 
      ? Math.round((updated.filter(h => h.completed).length / updated.length) * 100)
      : 0;
    setHistory(prev => ({ ...prev, [todayKey]: score }));
  };

  const deleteHabit = (id: string) => {
    setHabits(habits.filter(h => h.id !== id));
  };

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black tracking-tighter text-slate-900 italic">HABITS.</h2>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.25em] mt-1">Daily Recurrence</p>
        </div>
        <div className="bg-indigo-600 text-white px-4 py-2 rounded-2xl flex items-center gap-2 shadow-lg shadow-indigo-100">
          <Zap className="w-4 h-4 fill-white" />
          <span className="text-sm font-black">{habits.filter(h => h.completed).length}/{habits.length}</span>
        </div>
      </div>

      <form onSubmit={addHabit} className="relative">
        <input 
          type="text"
          value={newHabit}
          onChange={(e) => setNewHabit(e.target.value)}
          placeholder="I will drink water..."
          className="w-full pl-6 pr-16 py-5 bg-white border border-slate-100 rounded-[2rem] shadow-sm focus:ring-4 focus:ring-indigo-50 transition-all font-bold text-slate-700 text-sm"
        />
        <button type="submit" className="absolute right-2.5 top-2.5 w-11 h-11 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-transform">
          <Plus className="w-6 h-6" />
        </button>
      </form>

      <div className="space-y-4">
        {habits.map(habit => (
          <div 
            key={habit.id}
            onClick={() => toggleHabit(habit.id)}
            className={`
              flex items-center gap-4 p-5 rounded-[2rem] border transition-all cursor-pointer active:scale-[0.98]
              ${habit.completed 
                ? 'bg-white border-transparent opacity-60' 
                : 'bg-white border-slate-100 shadow-sm'
              }
            `}
          >
            <div className={`
              w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300
              ${habit.completed ? 'bg-green-500 text-white shadow-lg shadow-green-100' : 'border-2 border-slate-100'}
            `}>
              {habit.completed && <CheckCircle2 className="w-5 h-5" />}
            </div>
            
            <div className="flex-1">
              <p className={`text-base font-bold transition-all ${habit.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>
                {habit.text}
              </p>
              <div className="flex items-center gap-1 mt-0.5">
                <Flame className={`w-3 h-3 ${habit.streak > 0 ? 'text-orange-500 fill-orange-500' : 'text-slate-200'}`} />
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{habit.streak} DAY STREAK</span>
              </div>
            </div>

            <button 
              onClick={(e) => { e.stopPropagation(); deleteHabit(habit.id); }}
              className="p-2 text-slate-200 hover:text-red-500 transition-colors"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        ))}
        
        {habits.length > 0 && (
          <button 
            onClick={() => setHabits(habits.map(h => ({ ...h, completed: false })))}
            className="w-full py-4 border-2 border-dashed border-slate-200 rounded-[2rem] flex items-center justify-center gap-2 text-slate-400 hover:text-indigo-600 hover:border-indigo-200 transition-all text-xs font-black uppercase tracking-widest mt-8"
          >
            <RotateCcw className="w-4 h-4" />
            Reset Today's Progress
          </button>
        )}

        {habits.length === 0 && (
          <div className="py-20 text-center space-y-4">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 opacity-50">
              <Zap className="w-10 h-10 text-slate-300" />
            </div>
            <p className="text-slate-400 font-black text-xs uppercase tracking-[0.3em]">No habits defined yet</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Habits;
