
import React, { useState, useEffect, useRef } from 'react';
import { 
  BrainCircuit, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  Zap,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { getGeminiResponse } from '../services/gemini';
import { Task, Habit, JournalEntry } from '../types';

interface AICoachProps {
  tasks: Task[];
  habits: Habit[];
  journals: Record<string, JournalEntry>;
}

const AICoach: React.FC<AICoachProps> = ({ tasks, habits, journals }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{role: 'user' | 'ai', text: string}[]>([
    { role: 'ai', text: "Hey! I'm your LifeSync AI coach. Looking at your data, you've got a busy day ahead. How can I help you stay focused today?" }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;
    
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const systemContext = `
        You are LifeSync AI, a professional life coach.
        Current Context:
        - Habits: ${habits.map(h => `${h.text} (${h.completed ? 'Done' : 'Pending'}, streak: ${h.streak})`).join(', ')}
        - Tasks: ${tasks.filter(t => !t.completed).map(t => t.text).join(', ')}
        Be encouraging, data-driven, and brief.
      `;
      const aiResponse = await getGeminiResponse(userMsg, systemContext);
      setMessages(prev => [...prev, { role: 'ai', text: aiResponse || "I'm sorry, I missed that. Can you repeat?" }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'ai', text: "Error syncing with brain. Try again." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="h-[calc(100vh-180px)] flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Voice Mode Visualizer Overlay (Decorative) */}
      <div className="p-6 bg-slate-900 text-white rounded-b-[3rem] shadow-2xl relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
           <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,#4f46e5,transparent)]" />
        </div>
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center animate-pulse shadow-lg shadow-indigo-500/50">
               <BrainCircuit className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-xs font-black uppercase tracking-widest text-indigo-300">Synchronized</p>
              <h2 className="text-xl font-bold tracking-tight italic">AI COACH MODE</h2>
            </div>
          </div>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map(i => (
              <div 
                key={i} 
                className="w-1 bg-indigo-400 rounded-full animate-bounce"
                style={{ height: `${Math.random() * 20 + 5}px`, animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
        {messages.map((msg, idx) => (
          <div 
            key={idx} 
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-${msg.role === 'user' ? 'right' : 'left'}-4 duration-300`}
          >
            <div className={`
              max-w-[85%] p-5 rounded-[1.75rem] text-sm font-semibold leading-relaxed shadow-sm
              ${msg.role === 'user' 
                ? 'bg-slate-900 text-white rounded-tr-none' 
                : 'bg-white border border-slate-100 text-slate-700 rounded-tl-none'
              }
            `}>
              {msg.text}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-100 p-4 rounded-[1.75rem] rounded-tl-none flex gap-1">
              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" />
              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.2s]" />
              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white border-t border-slate-100">
        <div className="flex gap-3">
          <button className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center active:scale-95 transition-all shadow-sm">
            <Mic className="w-6 h-6" />
          </button>
          <div className="flex-1 relative">
            <input 
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask for advice or focus..."
              className="w-full h-14 pl-6 pr-14 bg-slate-50 border-none rounded-2xl text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:bg-white focus:ring-4 focus:ring-indigo-50 transition-all"
            />
            <button 
              onClick={handleSend}
              className="absolute right-2 top-2 w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center shadow-lg active:scale-90 transition-all"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
        <p className="text-center text-[9px] font-bold text-slate-300 uppercase tracking-widest mt-4">
          Powered by Gemini 3 Flash Intelligence
        </p>
      </div>
    </div>
  );
};

export default AICoach;
