
import React, { useState } from 'react';
import { ListTodo, Plus, CheckCircle2, Trash2, Clock, Calendar } from 'lucide-react';
import { Task } from '../types';

interface TasksProps {
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
}

const Tasks: React.FC<TasksProps> = ({ tasks, setTasks }) => {
  const [newTask, setNewTask] = useState('');

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    const task: Task = {
      id: Date.now().toString(),
      text: newTask.trim(),
      completed: false,
      createdAt: Date.now()
    };
    setTasks([task, ...tasks]);
    setNewTask('');
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black tracking-tighter text-slate-900 italic uppercase">Missions.</h2>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.25em] mt-1">Today's Special</p>
        </div>
        <div className="bg-slate-900 text-white px-4 py-2 rounded-2xl flex items-center gap-2 shadow-lg">
          <ListTodo className="w-4 h-4" />
          <span className="text-sm font-black">{tasks.filter(t => !t.completed).length}</span>
        </div>
      </div>

      <form onSubmit={addTask} className="relative">
        <input 
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="New mission objective..."
          className="w-full pl-6 pr-16 py-5 bg-white border border-slate-100 rounded-[2rem] shadow-sm focus:ring-4 focus:ring-indigo-50 transition-all font-bold text-slate-700 text-sm"
        />
        <button type="submit" className="absolute right-2.5 top-2.5 w-11 h-11 bg-slate-900 text-white rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-transform">
          <Plus className="w-6 h-6" />
        </button>
      </form>

      <div className="space-y-4">
        {tasks.map(task => (
          <div 
            key={task.id}
            onClick={() => toggleTask(task.id)}
            className={`
              flex items-center gap-4 p-5 rounded-[2rem] border transition-all cursor-pointer active:scale-[0.98]
              ${task.completed 
                ? 'bg-slate-50 border-transparent opacity-50' 
                : 'bg-white border-slate-100 shadow-sm'
              }
            `}
          >
            <div className={`
              w-7 h-7 rounded-xl flex items-center justify-center transition-all duration-300
              ${task.completed ? 'bg-indigo-600 text-white' : 'border-2 border-slate-100'}
            `}>
              {task.completed && <CheckCircle2 className="w-5 h-5" />}
            </div>
            
            <div className="flex-1">
              <p className={`text-sm font-bold transition-all ${task.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>
                {task.text}
              </p>
              <div className="flex items-center gap-3 mt-1">
                <div className="flex items-center gap-1 text-[9px] font-bold text-slate-300 uppercase">
                  <Clock className="w-3 h-3" />
                  {new Date(task.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
                <div className="flex items-center gap-1 text-[9px] font-bold text-slate-300 uppercase">
                  <Calendar className="w-3 h-3" />
                  Today
                </div>
              </div>
            </div>

            <button 
              onClick={(e) => { e.stopPropagation(); deleteTask(task.id); }}
              className="p-2 text-slate-200 hover:text-red-500 transition-colors"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        ))}

        {tasks.length === 0 && (
          <div className="py-24 text-center">
            <div className="w-20 h-20 bg-indigo-50 rounded-[2.5rem] flex items-center justify-center mx-auto mb-6 rotate-12">
              <ListTodo className="w-10 h-10 text-indigo-200" />
            </div>
            <p className="text-slate-400 font-black text-xs uppercase tracking-[0.4em]">All Missions Clear</p>
            <p className="text-slate-300 text-[10px] mt-2 font-medium italic">"Yoga is excellence in action."</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Tasks;
