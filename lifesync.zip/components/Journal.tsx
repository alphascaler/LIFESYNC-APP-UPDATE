
import React, { useState, useEffect } from 'react';
import { BookOpen, Smile, Frown, Sparkles, Send, Quote, Wand2, Lightbulb, TrendingUp } from 'lucide-react';
import { JournalEntry } from '../types';
import { analyzeJournal } from '../services/gemini';

interface JournalProps {
  journals: Record<string, JournalEntry>;
  setJournals: React.Dispatch<React.SetStateAction<Record<string, JournalEntry>>>;
  todayKey: string;
}

const Journal: React.FC<JournalProps> = ({ journals, setJournals, todayKey }) => {
  const [content, setContent] = useState(journals[todayKey]?.content || '');
  const [selectedMood, setSelectedMood] = useState(journals[todayKey]?.mood || 'neutral');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastReflect, setLastReflect] = useState<any>(null);

  const moods = [
    { id: 'happy', icon: Smile, color: 'text-green-500', bg: 'bg-green-50', label: 'Happy' },
    { id: 'neutral', icon: Sparkles, color: 'text-indigo-500', bg: 'bg-indigo-50', label: 'Neutral' },
    { id: 'learned', icon: Lightbulb, color: 'text-amber-500', bg: 'bg-amber-50', label: 'Learnt' },
    { id: 'improve', icon: TrendingUp, color: 'text-purple-500', bg: 'bg-purple-50', label: 'Improve' },
    { id: 'sad', icon: Frown, color: 'text-blue-500', bg: 'bg-blue-50', label: 'Sad' },
  ];

  const handleSave = () => {
    setJournals(prev => ({
      ...prev,
      [todayKey]: {
        date: todayKey,
        content,
        mood: selectedMood,
        aiReflection: lastReflect?.reflection || prev[todayKey]?.aiReflection
      }
    }));
  };

  const runReflection = async () => {
    if (!content.trim()) return;
    setIsAnalyzing(true);
    try {
      const result = await analyzeJournal(content);
      setLastReflect(result);
      setJournals(prev => ({
        ...prev,
        [todayKey]: {
          ...prev[todayKey],
          content,
          mood: selectedMood,
          aiReflection: result.reflection
        }
      }));
    } catch (e) {
      console.error("Analysis failed", e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black tracking-tighter text-slate-900 italic">LOG.</h2>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.25em] mt-1">Conscious Reflection</p>
        </div>
        <button 
          onClick={handleSave}
          className="bg-indigo-600 text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl active:scale-95 transition-all"
        >
          Save
        </button>
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-100 space-y-6">
        <div className="flex justify-between items-center gap-2 overflow-x-auto no-scrollbar pb-2">
          {moods.map(mood => (
            <button 
              key={mood.id}
              onClick={() => {
                if ("vibrate" in navigator) navigator.vibrate(5);
                setSelectedMood(mood.id);
              }}
              className={`
                flex-shrink-0 w-14 h-14 rounded-[1.25rem] flex flex-col items-center justify-center gap-1 transition-all duration-300
                ${selectedMood === mood.id ? mood.bg : 'bg-slate-50 grayscale opacity-40'}
              `}
            >
              <mood.icon className={`w-5 h-5 ${selectedMood === mood.id ? mood.color : 'text-slate-400'}`} />
              <span className="text-[7px] font-black uppercase tracking-tighter opacity-80">{mood.label}</span>
            </button>
          ))}
        </div>

        <textarea 
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="What did you learn? How can you improve? Or just vent..."
          className="w-full h-48 bg-slate-50 border-none rounded-[1.5rem] p-6 text-sm font-semibold text-slate-700 placeholder:text-slate-300 leading-relaxed focus:bg-white focus:ring-4 focus:ring-indigo-50 transition-all resize-none shadow-inner"
        />

        <button 
          onClick={runReflection}
          disabled={isAnalyzing || !content.trim()}
          className={`
            w-full py-5 rounded-[1.25rem] flex items-center justify-center gap-3 font-black text-xs uppercase tracking-[0.2em] transition-all shadow-lg
            ${isAnalyzing ? 'bg-indigo-400' : 'bg-slate-900 active:scale-[0.98] shadow-slate-200'} text-white
          `}
        >
          {isAnalyzing ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <Wand2 className="w-5 h-5 text-indigo-400" />
          )}
          {isAnalyzing ? 'AI ANALYZING...' : 'AI REFLECTION'}
        </button>
      </div>

      {(lastReflect || journals[todayKey]?.aiReflection) && (
        <div className="bg-indigo-50 border border-indigo-100 p-8 rounded-[2.5rem] relative overflow-hidden animate-in zoom-in-95 duration-700">
          <div className="absolute -top-4 -left-4 opacity-10">
            <Quote className="w-20 h-20 text-indigo-600" />
          </div>
          <div className="relative z-10 space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-500" />
              <span className="text-[10px] font-black uppercase tracking-widest text-indigo-400">AI Assistant Advice</span>
            </div>
            <p className="text-indigo-900 text-sm font-semibold leading-relaxed">
              {lastReflect?.reflection || journals[todayKey]?.aiReflection}
            </p>
            {(lastReflect?.advice || lastReflect?.mood) && (
              <div className="pt-2 border-t border-indigo-100 space-y-2">
                {lastReflect?.mood && (
                  <p className="text-[9px] font-black uppercase tracking-widest text-indigo-500">
                    Tone: {lastReflect.mood}
                  </p>
                )}
                {lastReflect?.advice && (
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-indigo-400 mb-1">Recommended Action</p>
                    <p className="text-indigo-800 text-xs italic">"{lastReflect.advice}"</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Journal;
