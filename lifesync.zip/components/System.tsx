import React, { useState } from 'react';
import { 
  Smartphone, 
  Download, 
  Copy, 
  Check, 
  ExternalLink, 
  ShieldCheck, 
  Terminal as TerminalIcon, 
  FileCode,
  AlertTriangle,
  Package,
  Globe,
  Code2,
  Github,
  Rocket,
  CheckCircle,
  Play,
  Image as ImageIcon,
  ShieldAlert,
  ChevronRight,
  Info,
  XCircle,
  Search,
  CheckSquare,
  Command
} from 'lucide-react';
import { AppState } from '../types';

interface SystemProps {
  appState: AppState;
  onCopy: () => void;
  copied: boolean;
}

const System: React.FC<SystemProps> = ({ appState, onCopy, copied }) => {
  const [isGenerating, setIsGenerating] = useState(false);

  const generateStandalone = () => {
    setIsGenerating(true);
    // Simple bridge for users to test offline
    const htmlContent = `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>LifeSync Bridge</title><script src="https://cdn.tailwindcss.com"></script></head><body class="bg-indigo-600 text-white min-h-screen flex items-center justify-center p-8 text-center"><div class="space-y-6"> <h1 class="text-4xl font-black italic">LIFESYNC</h1><p class="opacity-80">Emergency standalone launcher.</p><button onclick="window.location.href='${window.location.href}'" class="bg-white text-indigo-600 px-8 py-4 rounded-2xl font-black uppercase">Launch App</button></div></body></html>`;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'LifeSync_Launcher.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => setIsGenerating(false), 1500);
  };

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-40">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black tracking-tighter text-slate-900 italic uppercase leading-none">TERMINAL.</h2>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.25em] mt-2">Publishing Workflow</p>
        </div>
        <TerminalIcon className="w-8 h-8 text-slate-900" />
      </div>

      {/* QUICK COMMAND GUIDE */}
      <div className="bg-slate-900 rounded-[3rem] p-8 text-white shadow-2xl space-y-6 relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
             <Command className="w-5 h-5 text-indigo-400" />
             <h3 className="text-sm font-black italic uppercase tracking-widest text-indigo-300">Deployment Commands</h3>
          </div>
          
          <div className="space-y-3 font-mono text-[10px] leading-relaxed">
            <div className="p-4 bg-white/5 rounded-xl border border-white/10 hover:border-indigo-500/50 transition-colors">
               <p className="text-slate-500 mb-1"># 1. Start Local Repo</p>
               <p className="text-indigo-400">git init</p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl border border-white/10 hover:border-indigo-500/50 transition-colors">
               <p className="text-slate-500 mb-1"># 2. Add and Commit Files</p>
               <p className="text-indigo-400">git add . && git commit -m "PWA Build"</p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl border border-white/10 hover:border-indigo-500/50 transition-colors">
               <p className="text-slate-500 mb-1"># 3. Push to GitHub</p>
               <p className="text-indigo-400">git push -u origin main</p>
            </div>
          </div>
        </div>
      </div>

      {/* THE LIVE LINK VERIFIER */}
      <div className="bg-white border border-slate-100 rounded-[3rem] p-8 shadow-xl space-y-6">
        <div className="flex items-center gap-3">
           <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
              <Globe className="w-5 h-5" />
           </div>
           <div>
             <h3 className="text-lg font-black italic uppercase tracking-tighter text-slate-900">Final Verification.</h3>
             <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Ready for PWABuilder</p>
           </div>
        </div>

        <div className="space-y-3">
           <StepItem label="Meta Description" status="PASS" desc="Found in code" />
           <StepItem label="Manifest Assets" status="PASS" desc="512x512 Icon Linked" />
           <StepItem label="Theme Color" status="PASS" desc="#4f46e5" />
        </div>

        <div className="p-5 bg-orange-50 rounded-[2rem] border border-orange-100 space-y-3">
           <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-orange-500" />
              <span className="text-[9px] font-black uppercase tracking-widest text-orange-600">Golden Rule</span>
           </div>
           <p className="text-[11px] leading-relaxed font-medium text-slate-600">
             Your APK link should look like: <br/>
             <span className="text-slate-900 font-black">https://username.github.io/lifesync/</span><br/>
             <span className="text-red-500 font-bold strike">NOT github.com/username/lifesync</span>
           </p>
        </div>

        <button 
          onClick={onCopy}
          className="w-full py-4 bg-indigo-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          Copy Live Link
        </button>
      </div>

      <div className="bg-slate-50 border border-slate-100 p-8 rounded-[3rem] text-center">
         <p className="text-[9px] font-black text-slate-300 uppercase tracking-[0.4em]">LifeSync Deployment Engine v5.3</p>
      </div>
    </div>
  );
};

const StepItem = ({ label, status, desc }: { label: string, status: string, desc: string }) => (
  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
    <div>
      <p className="text-[10px] font-black text-slate-800 uppercase tracking-tight">{label}</p>
      <p className="text-[8px] font-bold text-slate-400 uppercase">{desc}</p>
    </div>
    <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full">
       <Check className="w-3 h-3" />
       <span className="text-[9px] font-black">{status}</span>
    </div>
  </div>
);

export default System;