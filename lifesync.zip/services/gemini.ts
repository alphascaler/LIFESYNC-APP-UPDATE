
import { GoogleGenAI, Type } from "@google/genai";

export const getGeminiResponse = async (prompt: string, systemInstruction?: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      systemInstruction: systemInstruction || "You are LifeSync, a highly intelligent and supportive life management assistant.",
      temperature: 0.7,
      topP: 0.95,
      topK: 40,
    }
  });
  return response.text;
};

export const analyzeJournal = async (content: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this journal entry and provide a supportive reflection, identifying the core emotion and one actionable piece of advice. Keep it under 100 words.\n\nEntry: ${content}`,
    config: {
      systemInstruction: "You are an empathetic journal assistant for LifeSync.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          reflection: { type: Type.STRING },
          mood: { type: Type.STRING },
          advice: { type: Type.STRING }
        },
        required: ["reflection", "mood", "advice"]
      }
    }
  });
  return JSON.parse(response.text || "{}");
};
